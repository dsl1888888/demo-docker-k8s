#!/bin/sh
exec java ${JAVA_OPS} -jar /app/app.jar
